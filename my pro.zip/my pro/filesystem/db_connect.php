<?php 

$conn= new mysqli('localhost','root','','jinka')or die("Could not connect to mysql".mysqli_error($con));
