-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2022 at 01:43 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jinka`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `coment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `user_id`, `pid`, `coment`) VALUES
(18, 1, 852, 'hello'),
(19, 1, 852, 'hello'),
(20, 1, 852, 'hello'),
(21, 1, 852, 'hello'),
(22, 1, 0, 'fvf'),
(23, 1, 0, 'fvf'),
(24, 1, 0, 'fvf'),
(25, 1, 0, 'fvf');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `user_id` int(30) NOT NULL,
  `folder_id` int(30) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_path` text NOT NULL,
  `is_public` tinyint(1) DEFAULT 0,
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `name`, `description`, `user_id`, `folder_id`, `file_type`, `file_path`, `is_public`, `date_updated`) VALUES
(1, 'My File', 'This is my file', 1, 11, 'txt', '1616126640_My File.txt', 1, '2021-03-19 11:04:13'),
(2, 'e', 'hello', 1, 0, 'jpg', '1644239520_e.jpg', 0, '2022-02-07 13:12:33'),
(3, 'e ||1', 'welcome', 3, 0, 'jpg', '1644314280_e.jpg', 0, '2022-02-08 09:58:14'),
(4, 'elias', 'jshfhvjknh', 3, 0, 'jpg', '1644426060_elias.jpg', 0, '2022-02-09 17:01:19'),
(6, 'images (1)', 'JYHJJ', 3, 0, 'jfif', '1646459520_images (1).jfif', 0, '2022-03-05 05:52:38'),
(7, 'images (3)', 'SDFVV', 3, 14, 'jfif', '1646459580_images (3).jfif', 0, '2022-03-05 05:53:30');

-- --------------------------------------------------------

--
-- Table structure for table `folders`
--

CREATE TABLE `folders` (
  `id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `name` varchar(200) NOT NULL,
  `parent_id` int(30) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `folders`
--

INSERT INTO `folders` (`id`, `user_id`, `name`, `parent_id`) VALUES
(10, 3, 'My Folder', 0),
(11, 1, 'New Folder', 0),
(13, 1, 'qajela gech', 0),
(14, 3, 'GROUP ONE', 0);

-- --------------------------------------------------------

--
-- Table structure for table `hard`
--

CREATE TABLE `hard` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `folder_id` int(11) NOT NULL,
  `owner` varchar(100) NOT NULL,
  `col` int(11) NOT NULL,
  `row` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` int(11) NOT NULL,
  `is_public` int(11) NOT NULL,
  `date_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `descr` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hard`
--

INSERT INTO `hard` (`id`, `image`, `name`, `user_id`, `folder_id`, `owner`, `col`, `row`, `email`, `phone`, `is_public`, `date_updated`, `descr`) VALUES
(1, 'download.jpg', '', 1, 0, 'mamed', 5, 45, '+251963999539', 0, 0, '2022-02-07 07:58:55', 'ella image'),
(2, 'elias.jpg', '', 1, 0, 'gech', 3454, 76, '+251963999539', 0, 0, '2022-02-07 07:59:30', ' image'),
(3, 'elias.jpg', '', 1, 0, 'gech', 3454, 76, 'eliasgalchu08@gmail.com', 2147483647, 0, '2022-02-07 08:01:52', ' image'),
(4, 'elias.jpg', '', 1, 0, 'meka', 23, 45, 'eliasgalchu08@gmail.com', 2147483647, 0, '2022-02-07 08:02:24', ' image2'),
(5, 'elias.jpg', '', 1, 0, 'meka', 23, 45, 'eliasgalchu08@gmail.com', 2147483647, 0, '2022-02-07 08:05:02', ' image2'),
(6, 'elias.jpg', '', 1, 0, 'meka', 23, 45, 'eliasgalchu08@gmail.com', 2147483647, 0, '2022-02-07 08:06:21', ' image2'),
(7, 'elias.jpg', '', 1, 0, 'meka', 23, 45, 'eliasgalchu08@gmail.com', 2147483647, 0, '2022-02-07 08:13:20', ' image2'),
(8, 'elias.jpg', '', 1, 0, 'meka', 23, 45, 'eliasgalchu08@gmail.com', 2147483647, 0, '2022-02-07 08:14:13', ' image2'),
(9, 'elias.jpg', '', 1, 0, 'meka', 23, 45, 'eliasgalchu08@gmail.com', 2147483647, 0, '2022-02-07 08:14:59', ' image2'),
(10, 'jku.png', '', 1, 0, '42', 2, 56, 'eliasgalchu08@gmail.com', 2147483647, 0, '2022-02-07 08:15:56', ' image2'),
(11, 'e.jpg', '', 1, 0, 'mamed', 5, 0, 'eliasgalchu08@gmail.com', 2147483647, 0, '2022-02-07 08:25:44', ' image2'),
(12, 'e.jpg', '', 1, 0, 'mamed', 5, 0, 'eliasgalchu08@gmail.com', 2147483647, 0, '2022-02-07 08:26:07', ' image2'),
(13, 'e.jpg', 'elias galchu', 1, 0, 'elias', 5, 0, 'eliasgalchu08@gmail.com', 2147483647, 0, '2022-02-07 08:26:26', ' image2'),
(14, 'jku.png', 'ELIAS GALCHU', 3, 0, 'me', 4, 56, 'woynegech@gmail.com', 2147483647, 0, '2022-02-07 10:24:27', 'werfe'),
(15, 'jku.png', 'ELIAS GALCHU', 3, 0, 'me', 4, 56, 'woynegech@gmail.com', 2147483647, 0, '2022-02-07 10:25:34', 'werfe');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `descr` text NOT NULL,
  `date_post` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `poid` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `coment` text DEFAULT NULL,
  `pid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `image`, `descr`, `date_post`, `poid`, `user_id`, `coment`, `pid`) VALUES
(2, 'e.jpg', 'HTML form: First we create an HTML form that need to take user input from keyboard. HTML form is a document which stores information of a user on a web server using interactive controls. An HTML form contains different kind of information such as username, password, contact number, email id etc.  The elements that are used in an HTML form are check box, input box, radio buttons, submit buttons etc. With the help of these elements, the information of an user is submitted on the web server. The form tag is used to create an HTML form.', '2022-02-07 13:47:49', 0, NULL, NULL, NULL),
(4, 'hqdefault.jpg', 'The rand() function generates a random integer.  Example tip: If you want a random integer between 10 and 100 (inclusive), use rand (10,100).  Tip: As of PHP 7.1, the rand() function has been an alias of the mt_rand() function.', '2022-02-07 16:16:07', 0, 1, NULL, 787),
(5, 'e.jpg', 'An alert box is used in the website to display a warning message to the user that they have entered the wrong value other than what is required to fill in that position. An alert box can still be used for friendlier messages. The alert box gives only one button “OK” to select and proceed.   The alert message just like a pop-up window on the screen. Using this you can alert to the user with some information and message. PHP doesn’t support alert message box because it is a server-side language but you can use JavaScript code within the PHP body to alert the message box on the screen.', '2022-02-07 16:25:34', 0, 1, NULL, 852),
(6, 'jku.png', ' image', '2022-02-08 07:52:38', 0, 1, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comment`
--

CREATE TABLE `tbl_comment` (
  `comment_id` int(11) NOT NULL,
  `parent_comment_id` int(11) DEFAULT NULL,
  `comment` varchar(200) NOT NULL,
  `comment_sender_name` varchar(40) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_comment`
--

INSERT INTO `tbl_comment` (`comment_id`, `parent_comment_id`, `comment`, `comment_sender_name`, `date`) VALUES
(8, 0, '  fgh', 'ella', '2022-02-08 11:49:03'),
(9, 0, 'ht', 'egalcho', '2022-02-08 11:53:46'),
(10, 0, '  gtg', 'egalchu', '2022-02-08 11:55:51'),
(11, 9, 'nhhj', 'downloads', '2022-02-08 11:56:12'),
(12, 0, '  what are you doing know man', 'lectur', '2022-02-08 19:15:52'),
(13, 12, 'nothing boss', 'ella', '2022-02-08 19:16:37'),
(14, 0, '  where are you man', 'egalcho', '2022-02-08 19:25:07'),
(15, 0, '  hjkk', 'egalchu', '2022-02-08 19:31:51'),
(16, 9, 'why', 'ella', '2022-02-08 19:32:12'),
(17, 8, 'i dont', 'egalcho', '2022-02-08 19:32:42'),
(18, 0, '  hello', '', '2022-02-09 12:45:09'),
(19, 0, '  what are ', 'sale', '2022-02-09 18:01:59'),
(20, 19, '  nothing', 'ella', '2022-02-09 18:02:26'),
(21, 0, '  ghh', 'email ', '2022-03-04 18:07:38'),
(22, 0, '  NICE', 'FANU', '2022-03-05 06:56:44');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_like_unlike`
--

CREATE TABLE `tbl_like_unlike` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `like_unlike` int(2) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_like_unlike`
--

INSERT INTO `tbl_like_unlike` (`id`, `member_id`, `comment_id`, `like_unlike`, `date`) VALUES
(43, 1, 8, 1, '2022-02-08 18:34:04'),
(44, 1, 9, 1, '2022-02-08 18:16:14'),
(45, 1, 11, 1, '2022-02-08 18:16:12'),
(46, 1, 10, 1, '2022-02-08 18:16:18'),
(47, 1, 12, 1, '2022-02-08 18:16:22'),
(48, 1, 13, 1, '2022-02-08 18:25:15'),
(49, 1, 14, 1, '2022-02-08 18:25:28'),
(50, 1, 17, 1, '2022-02-08 18:34:09'),
(51, 1, 20, 0, '2022-02-09 17:03:29'),
(52, 1, 21, 1, '2022-03-05 05:57:03');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `name` varchar(200) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 2 COMMENT '1+admin , 2 = users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `type`) VALUES
(1, 'Administrator', 'admin', 'admin', 1),
(3, 'egalcho', 'egalcho', 'egalcho', 2),
(4, 'tare', 'tare', 'tare', 2),
(5, 'meka', 'meka', 'meka', 2),
(6, 'fantahun', 'fantahun', 'fantahun', 2),
(7, 'zak', 'zak', 'zak', 2),
(8, 'NOW', 'NOW', 'hello', 2),
(9, 'user', 'user', 'user', 2),
(10, 'new man', 'lectur', 'lectur', 2),
(11, '', 'egalcho', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `folders`
--
ALTER TABLE `folders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hard`
--
ALTER TABLE `hard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `tbl_like_unlike`
--
ALTER TABLE `tbl_like_unlike`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `folders`
--
ALTER TABLE `folders`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `hard`
--
ALTER TABLE `hard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_like_unlike`
--
ALTER TABLE `tbl_like_unlike`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
